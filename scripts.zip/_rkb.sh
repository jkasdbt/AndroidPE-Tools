# AndroidPE - Your IDE in your pocket !
# 
# AndroidPE is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# AndroidPE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with AndroidPE.  If not, see <https://www.gnu.org/licenses/>.

. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh



FORCE_ENABLED=false
ORACLE_ENABLED=false
cmd=""
data=""





_help(){
  log "${BOLD}AndroidPE : RKB Script${NC}"
  log "This script is designed to install and configure essential tools for Android development."
  echo ""
  log "${BOLD}Usage:${NC} rkb <command> [options] <data>"
  echo ""
  log "${BOLD}Commands:"
  log "  install     : Install tools such as NDK, JDK (17, 21, 22, 23, 24, 25)"
  log "  setup       : Set up the AndroidPE tools, including IDE and environment"
  log "  switchjdk   : Switch between different versions of JDK"
  log ""
  log "${BOLD}Options:"
  log "  -f|--force  : Force installation even if the version is already installed"
  log "  -o|--oracle : To install the JDK (-o to download the Oracle version)."
  log "  -h|--help   : Display this help message"
  echo ""
  log "${BOLD}Example usage:"
  log "  ${CYAN}rkb install jdk17${NC}          # Install JDK 17 from apt"
  log "  ${CYAN}rkb -o install jdk17${NC}       # Install JDK 17 from oracle"
  log "  ${CYAN}apt install openjdk-17-jdk${NC} # Install JDK 17 from apt"
  log "  ${CYAN}rkb install cmdline${NC}        # Install Cmdline"
  log "  ${CYAN}rkb install ndk${NC}            # Install Ndk"
  log "  ${CYAN}rkb setup ide${NC}              # Set up the IDE environment"
  log "  ${CYAN}rkb switchjdk 21${NC}           # Switch to JDK 21"
  echo ""
  log "${BOLD}Available"
  log "${WARNING}From orable : ${NC}17, 21, 22, 23, 24(64-bits only)"
  log "${WARNING}From apt    : ${NC}8, 17, 21, 25 "
  log "(${GREEN}'${BOLD}apt search jdk'${NC} for more details)."
}



OPTS=$(getopt -o foh -l force,oracle,help -- "$@") || exit 1
eval set -- "$OPTS"

while true; do
  case "$1" in
    -f|--force) FORCE_ENABLED=true; shift ;;
    -o|--oracle) ORACLE_ENABLED=true; shift ;;
    -h|--help) _help; exit 0 ;;
    --) shift; break ;;
  esac
done



cmd="$1"
data="$2"



install_openjdk() {
  local TCP="$PWD"
  URL="$1"
  ARCHIVE_NAME="$(basename $URL)"
  
  if [ "$FORCE_ENABLED" = "false" ]; then
    version=$(get_jdk_version "$URL")
    if [ -f "$PRE_JAVA_HOME/$version/bin/java" ] || [ -f "$PRE_JAVA_HOME/$version/jre/sh/java" ]; then
      _warning "This version ${NC}($version) ${WARNING}is already installed"
      log "Add ${Warning}-f${NC} after ${Warning}rkb${NC} to force the installation"
      return 1
    fi
  fi
    
  mkdir -p "$PRE_JAVA_HOME"
  cd "$PRE_JAVA_HOME" || return 1

  log "Cleaning previous JDK installation..."
  rm -rf "$ARCHIVE_NAME"

  log "Downloading JDK from ${INFO}$URL..."
  
  wget -O "$ARCHIVE_NAME" "$URL" || {
    _warning "Download failed !"
    return 1
  }

  log "Extracting the archive..."
  if tar -xf "$ARCHIVE_NAME"; then
    _success "JDK installed"
    switchjdk 17
  else
    _error "Extraction failed !"
    return 1
  fi

  if [ ! -f "$JAVA_HOME/bin/java" ] && [ ! -f "$JAVA_HOME/jre/sh/java" ]; then
    _error "[!!] The JDK not properly installed and configured."
    info "i" "Try again to reinstall (rkb install jdk17)."
  fi
    
  update-alternatives --remove-all java 2>/null
  update-alternatives --remove-all javac 2>/null
  
  cd "$TCP"
}



_setupIde(){
  if [ "$ORACLE_ENABLED" = "false" ]; then
    yes | apt remove openjdk-17-jdk
    yes | apt install openjdk-17-jdk
    switchjdk 17
  else
    install_openjdk "$jdk17"
  fi
  
  . $SCRIPTS/cmdline-tools.sh
  . $SCRIPTS/paths.sh
  
  if [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ] && [ -f "$PRE_JAVA_HOME/17.0.12/bin/java" ]; then
  . $SCRIPTS/paths.sh
    log ""
    _success "[✓] ide setup finished"
    log ""
  else
    if [ ! -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
      _error "[!!] The cmdline not properly installed and configured."
      info "i" "Try again to reinstall (rkb install cmdline)."
    fi
  fi
  
  update-alternatives --remove-all java 2>/null
  update-alternatives --remove-all javac 2>/null
  
  _info "A small upgrade and everything will be ready 😊👍."
  yes | apt upgrade
  _info "Configuration complete !"
  echo "If a particular tool has not been installed correctly,"
  echo "    Rerun the order or install it individually."
}



switchjdk() {
    if [ -z "$1" ]; then
        log "Usage: switchjdk <version>"
        log "Example: switchjdk 11"
        return 1
    fi
    
    update-alternatives --remove-all java 2>/null
    update-alternatives --remove-all javac 2>/null

    VERSION=$1
    CURRENT_FILE="$PRE_JAVA_HOME/version.txt"
    JVM_PATH=$(ls -d /usr/lib/jvm/*$VERSION* 2>/dev/null | grep -v "default" | head -n 1)

    if [ -z "$JVM_PATH" ]; then
        JVM_PATH=$(find "$PRE_JAVA_HOME" -maxdepth 1 -type d -name "*$VERSION*" \
            -exec test -x "{}/bin/java" \; -print 2>/dev/null | head -n 1)
    fi
    
    if [ -z "$JVM_PATH" ]; then
        JVM_PATH=$(find "$PRE_JAVA_HOME" -maxdepth 1 -type d -name "*$VERSION*" \
            -exec test -x "{}/jre/sh/java" \; -print 2>/dev/null | head -n 1)
    fi

    if [ -z "$JVM_PATH" ]; then
        _warning "[x] No JDK matching '$VERSION' found."
        log "install a new jdk with this command"
        log "'rkb install jdk17' or 'apt install openjdk-17-jdk'"
        return 1
    fi

    export JAVA_HOME="$JVM_PATH"
    export PATH="$JAVA_HOME/bin:$JAVA_HOME/jre/sh:$PATH"

    mkdir -p "$PRE_JAVA_HOME"
    echo "$JAVA_HOME" > "$CURRENT_FILE"

    echo "JAVA_HOME set to $JAVA_HOME"
    echo "Java now points to:"
    "$JAVA_HOME/bin/java" -version
    
    . $SCRIPTS/paths.sh
}



case "$cmd" in
  "init")
  . $SCRIPTS/init-host.sh
  ;;
  "switchjdk")
  switchjdk $2
  ;;
  install)
    if [ "$data" = "ndk" ]; then
      if [ -f "$HOME/ndk-installer.sh" ]; then rm $HOME/ndk-installer.sh; fi
      wget https://github.com/jkasdbt/AndroidPE-NDK/raw/main/ndk-install.sh --no-verbose --show-progress -N
      chmod +x $HOME/ndk-install.sh
      bash $HOME/ndk-install.sh
    elif [ "$data" = "cmdline" ]; then
      . $SCRIPTS/cmdline-tools.sh "$FORCE_ENABLED"
    elif [ "$data" = "jdk25" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        yes | apt install openjdk-25-jdk
      else
        _warning "not support install from ${ERROR}apt${WARNING} for this version"
      fi
    elif [ "$data" = "jdk24" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        _warning "not support install from ${ERROR}rkb -o install ...${WARNING} for this version"
      else
        install_openjdk "$jdk24"
      fi
    elif [ "$data" = "jdk23" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        _warning "not support install from ${ERROR}rkb -o install ...${WARNING} for this version"
      else
        install_openjdk "$jdk23"
      fi
    elif [ "$data" = "jdk22" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        _warning "Not support install from ${ERROR}rkb -o install ...${WARNING} for this version"
      else
        install_openjdk "$jdk22"
      fi
    elif [ "$data" = "jdk21" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        yes | apt install openjdk-21-jdk
      else
        install_openjdk "$jdk21"
      fi
    elif [ "$data" = "jdk17" ]; then
      if [ "$ORACLE_ENABLED" != "true" ]; then
        yes | apt install openjdk-17-jdk
      else
        install_openjdk "$jdk17"
      fi
    else
      info "*" "Use '--help for more details"
    fi
  ;;
  setup)
    if [ "$data" = "ide" ]; then
      echo "" > ${$DISTROS}/rootfs/etc/gshadow
      yes | apt update
      . $SCRIPTS/init-distro.sh
      _setupIde
    elif [ "$data" = "jvm" ]; then
      yes | apt install nodejs npm python3 openjdk-17-jdk kotlin gcc g++ groovy
    elif [ "$data" = "lsp" ]; then
      tmp_var="$PWD"
      cd ${HOME}
      yes | apt install wget
      wget ${lspLibs}
      echo "File extraction in progress, please wait."
      yes | unzip -o "libs.zip" -d "${ANDROIDPE_HOME}/caches"
      clear
      echo "Everything has been downloaded and configured"
      cd ${tmp_var}
    else
      info "*" "Use 'rkb setup ide' or --help"
    fi
  ;;
  --help|-h)
  _help
  ;;
  *)
    echo "use 'rkb -h or --help' for more details"
  ;;
esac
